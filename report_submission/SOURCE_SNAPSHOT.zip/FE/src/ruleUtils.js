import { MAX_LENGTH, OPERATORS } from "./constants.js";
import { translate } from "./i18n.js";

export const initialForm = {
  symbol: "BTCUSDT",
  timeframe: "1d",
  left: { type: "rsi", length: 14 },
  operator: "lt",
  target: { mode: "value", value: 30 },
  candleMode: "closed",
  triggerType: "once_per_bar_close",
  message: "",
};

export function ruleToForm(rule) {
  if (!rule) return structuredClone(initialForm);
  return {
    symbol: rule.symbol || "BTCUSDT",
    timeframe: rule.timeframe || "1d",
    left: { type: rule.indicator?.type || "rsi", length: rule.indicator?.length ?? 14 },
    operator: rule.operator || "lt",
    target: typeof rule.target === "number"
      ? { mode: "value", value: rule.target }
      : { mode: "indicator", type: rule.target.type, length: rule.target.length },
    candleMode: rule.candle_mode || "closed",
    triggerType: rule.trigger_type || "once_per_bar_close",
    message: rule.message || "",
  };
}

const isInt = (v) => Number.isInteger(Number(v)) && String(v).trim() !== "";

// Đọc số người dùng nhập, cho phép dấu phẩy phân cách hàng nghìn: "82,200.06" -> 82200.06.
// Dấu phẩy sai nhóm ("82,2") bị coi là không hợp lệ thay vì đoán nghĩa.
export function parseNumber(raw) {
  if (typeof raw === "number") return raw;
  const text = String(raw ?? "").trim();
  if (!/^[+-]?(\d{1,3}(,\d{3})+|\d*)(\.\d+)?$/.test(text) || !/\d/.test(text)) return NaN;
  return Number(text.replace(/,/g, ""));
}

function validateLength(length, label, errors, key, language) {
  if (!isInt(length) || Number(length) < 1 || Number(length) > MAX_LENGTH) {
    errors[key] = translate("{label}: chu kỳ phải là số nguyên từ 1 đến {max}.", language,
      { label: translate(label, language), max: MAX_LENGTH });
  }
}

// Trả về object lỗi theo từng trường; rỗng nghĩa là hợp lệ.
export function validateForm(form, language = "en") {
  const errors = {};
  if (!form.symbol) errors.symbol = translate("Hãy chọn symbol.", language);

  if (form.left.type !== "close") {
    validateLength(form.left.length, "Chỉ báo", errors, "leftLength", language);
  }

  if (form.target.mode === "value") {
    const value = parseNumber(form.target.value);
    if (!Number.isFinite(value)) {
      errors.targetValue = translate("Hãy nhập một con số.", language);
    } else if (form.left.type === "rsi" && (value < 0 || value > 100)) {
      errors.targetValue = translate("RSI luôn nằm trong khoảng 0–100.", language);
    }
  } else {
    validateLength(form.target.length, "Chỉ báo đích", errors, "targetLength", language);
    if (
      !errors.targetLength &&
      !errors.leftLength &&
      form.left.type === form.target.type &&
      Number(form.left.length) === Number(form.target.length)
    ) {
      errors.targetLength = translate("Hai vế giống hệt nhau nên cảnh báo không bao giờ kích hoạt.", language);
    }
  }
  return errors;
}

// Chuyển state của form thành JSON gửi backend (khớp mục 5.3 của plan).
export function buildPayload(form) {
  const indicator =
    form.left.type === "close"
      ? { type: "close" }
      : { type: form.left.type, length: Number(form.left.length) };

  const target =
    form.target.mode === "value"
      ? parseNumber(form.target.value)
      : { type: form.target.type, length: Number(form.target.length) };

  const payload = {
    symbol: form.symbol,
    timeframe: form.timeframe,
    indicator,
    operator: form.operator,
    target,
    candle_mode: form.candleMode,
    trigger_type: form.triggerType || "once_per_bar_close",
  };
  if (form.message && form.message.trim()) {
    payload.message = form.message.trim();
  }
  return payload;
}

const indicatorText = (i, language) => {
  if (!i) return "";
  if (i.type === "close") return translate("Giá", language);
  if (i.type === "mass_index") return `Mass Index(${i.length || 10})`;
  return `${i.type.toUpperCase()}(${i.length})`;
};

const LEGACY_OP_LABELS = {
  cross_above: "Cắt lên",
  cross_below: "Cắt xuống",
  gte: "Lớn hơn hoặc bằng",
  lte: "Nhỏ hơn hoặc bằng",
};

// Mô tả luật bằng chữ dễ đọc, ví dụ "BTCUSDT · 1D · RSI(14) nhỏ hơn 30".
export function describeRule(rule, language = "en") {
  const op = OPERATORS.find((o) => o.value === rule.operator);
  const fallback = LEGACY_OP_LABELS[rule.operator];
  const opText = op
    ? translate(op.label.split(" (")[0], language).toLowerCase()
    : fallback
    ? translate(fallback, language).toLowerCase()
    : rule.operator;
  const target = typeof rule.target === "number" ? rule.target : indicatorText(rule.target, language);
  return `${rule.symbol} · ${rule.timeframe.toUpperCase()} · ${indicatorText(rule.indicator, language)} ${opText} ${target}`;
}
