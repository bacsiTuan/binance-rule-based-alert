# Demo WebSocket: nhận nến và tự kết nối lại

Demo độc lập để chạy, kiểm thử và giải thích thiết kế. FastAPI, Redis và scheduler
Telegram hiện tại chưa gọi demo này; luồng chính vẫn dùng REST. Giá 100–103 trong
chế độ mặc định là dữ liệu giả lập, không phải giá Binance hoặc bằng chứng đo hiệu năng.

## 1. Hai lý do lựa chọn WebSocket

- Khi cần cập nhật liên tục, Binance đẩy bản tin trên một kết nối được duy trì,
  giúp giảm các lần REST polling và phần request weight tương ứng. Cách này phù hợp
  với luồng dữ liệu theo sự kiện: nhận bản tin rồi xử lý ngay.
- Reconnect là yêu cầu vận hành của kết nối dài hạn. Binance Spot quy định một
  phiên chỉ tồn tại 24 giờ, do đó demo chủ động đổi phiên sau 23 giờ 50 phút.
  Mất mạng có thể xảy ra sớm hơn; code cũng phải xử lý trường hợp đó.

WebSocket vẫn có giới hạn riêng: Spot giới hạn các bản tin điều khiển/PING/PONG
gửi vào server và số lần mở kết nối. Không trình bày WebSocket là cách bỏ qua
mọi rate limit. Phần reconnect trong demo dùng thời gian chờ tăng dần, có mức trần.

Nguồn chính thức đã đối chiếu ngày 15/10/2026:
[Binance Spot WebSocket Streams](https://github.com/binance/binance-spot-api-docs/blob/master/web-socket-streams.md).

## 2. Code cần mở khi giải thích

- [BinanceClient.stream_klines](BE/app/service/binance_client.py): mở WebSocket,
  đọc JSON, chuyển thành đối tượng `Candle` và cờ nến đã đóng.
- [ReconnectingKlineStream](BE/examples/websocket_demo.py): bọc `BinanceClient`
  để thêm đổi phiên, reconnect, backoff và đóng kết nối khi dừng.
- [Test offline](BE/tests/test_websocket_demo.py): đưa socket giả vào chính bộ đọc
  Binance thật, không dùng Internet, Redis, OpenAI hoặc Telegram.

OOP: `BinanceClient` đóng gói việc giao tiếp/đọc bản tin. `ReconnectingKlineStream`
giữ một đối tượng client để phối hợp, đây là composition. Đưa socket giả vào thay
socket thật là dependency injection, giúp kiểm thử mà không phụ thuộc mạng.

## 3. Chạy offline trên Windows

Mở PowerShell tại gốc project, sử dụng môi trường `.venv` đã cài dependency:

```powershell
Set-Location BE
& '..\.venv\Scripts\python.exe' -u -m examples.websocket_demo
Set-Location ..
```

Đầu ra mẫu đã chạy thành công; các dòng sau đều thuộc mô phỏng:

```text
SIMULATED data: no real network connection
SIMULATED connection #1: wss://stream.binance.com:9443/ws/btcusdt@kline_1h
BTCUSDT 1H close=100 candle_closed=False
BTCUSDT 1H close=101 candle_closed=True
Stream interrupted; reconnecting
Reconnect backoff: 1.0 seconds
SIMULATED connection #2: wss://stream.binance.com:9443/ws/btcusdt@kline_1h
BTCUSDT 1H close=102 candle_closed=False
BTCUSDT 1H close=103 candle_closed=True
```

Hai cập nhật đầu đi qua cùng kết nối #1. Sau lỗi giả lập, chương trình chờ một
giây rồi mở kết nối #2 và tiếp tục nhận dữ liệu. Không tạo REST request cho từng giá.

Chạy bộ kiểm thử từ gốc project:

```powershell
& '.\.venv\Scripts\python.exe' -m pytest BE/tests/test_websocket_demo.py -v
```

12 trường hợp kiểm thử đã đạt: nhiều cập nhật trên cùng kết nối; reconnect sau lỗi;
backoff 1–2–4–4 giây với sleep giả; reset backoff khi có dữ liệu; đổi phiên;
timeout khi không có bản tin; hủy tác vụ và đóng socket; lỗi không retry được;
và kiểm tra tuổi thọ phiên không hợp lệ.

Test đổi phiên tăng đồng hồ giả lên 23 giờ 50 phút, không chờ gần một ngày.
Test socket im lặng dùng phiên 0,02 giây để kiểm tra timeout nhận dữ liệu.
Đây là kiểm tra logic, không chứng minh kết nối thật đã chạy ổn định 24 giờ.

## 4. Chạy Binance Spot thật khi muốn thử

Lệnh này kết nối Internet và chỉ đọc market data công khai; không cần Binance key:

```powershell
Set-Location BE
& '..\.venv\Scripts\python.exe' -u -m examples.websocket_demo --live --events 5
Set-Location ..
```

Dừng sau 5 bản tin, hoặc nhấn Ctrl+C. Chế độ live là lựa chọn riêng, không tự
bật trong test offline. Lần bổ sung demo này chỉ chạy và nghiệm thu chế độ giả lập.
Linux/macOS có thể dùng `../.venv/bin/python` khi đứng trong thư mục `BE`.

## 5. Nội dung giải thích khi trình bày

"Ứng dụng chính hiện lấy dữ liệu bằng REST. Em xây dựng thêm một prototype
WebSocket có kiểm thử giả lập để đánh giá hướng cập nhật theo sự kiện. Nhiều bản
tin được nhận trên cùng một kết nối, giảm việc polling REST khi cần dữ liệu liên
tục. Khi kết nối mất, client chờ tăng dần rồi kết nối lại. Vì Binance Spot giới
hạn phiên 24 giờ, prototype chủ động đổi phiên sớm. Các test dùng socket và đồng
hồ giả để tái hiện lỗi và việc đổi phiên trong thời gian ngắn."

Khi nối vào hệ thống chính, cần thêm tải lịch sử bằng REST để tính chỉ báo,
bù nến bị thiếu trong lúc mất kết nối, chống trùng theo thời gian nến, xử lý
`candle_closed=True`, lưu Redis và kiểm tra rule. Reconnect riêng lẻ chưa bảo đảm
không mất hoặc không lặp dữ liệu. Demo không gửi cảnh báo hoặc tự động giao dịch.
