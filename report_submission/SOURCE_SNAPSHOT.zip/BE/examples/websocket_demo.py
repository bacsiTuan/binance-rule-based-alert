"""Standalone kline streaming demo. Default: simulated sockets, no external services.

Run from BE: python -m examples.websocket_demo
Real public Binance data: python -m examples.websocket_demo --live --events 5
"""

import argparse
import asyncio
import json
import logging
import math
import time
from contextlib import aclosing, asynccontextmanager

import httpx

from app.config import Settings
from app.errors import BinanceError
from app.service.binance_client import BinanceClient

logger = logging.getLogger(__name__)
SESSION_SECONDS = 23 * 3600 + 50 * 60  # Renew before Binance Spot's 24-hour limit.


class ReconnectingKlineStream:
    """Compose a BinanceClient with session renewal and capped retry backoff.

    Streaming only: no REST polling, Redis writes, AI calls or Telegram sends.
    """

    def __init__(self, client, *, session_seconds=SESSION_SECONDS, retry_delay=1,
                 max_retry_delay=30, connect=None, sleep=asyncio.sleep, clock=time.monotonic):
        if not math.isfinite(session_seconds) or not 0 < session_seconds < 86400:
            raise ValueError("session_seconds must be positive and below 24 hours")
        if not all(math.isfinite(v) for v in (retry_delay, max_retry_delay)) or not (
            0 < retry_delay <= max_retry_delay
        ):
            raise ValueError("Retry delays must be positive and capped above the initial delay")
        self.client = client
        self.session_seconds = session_seconds
        self.retry_delay = retry_delay
        self.max_retry_delay = max_retry_delay
        self.connect = connect
        self.sleep = sleep
        self.clock = clock

    async def events(self, symbol="BTCUSDT", interval="1h"):
        delay = self.retry_delay
        while True:
            rotate = False
            try:
                options = {"connect": self.connect} if self.connect is not None else {}
                async with aclosing(self.client.stream_klines(symbol, interval, **options)) as stream:
                    deadline = self.clock() + self.session_seconds
                    while True:
                        remaining = deadline - self.clock()
                        if remaining <= 0:
                            rotate = True
                            break
                        try:
                            # Timeout covers receiving, never the consumer's work after yield.
                            async with asyncio.timeout(remaining):
                                event = await anext(stream)
                        except StopAsyncIteration:
                            break
                        delay = self.retry_delay
                        yield event
            except TimeoutError:
                rotate = True
            except BinanceError as exc:
                if not exc.retryable:
                    raise
                logger.warning("Stream interrupted; reconnecting")
            if rotate:
                logger.info("Renewing WebSocket session before its maximum lifetime")
                continue
            logger.info("Reconnect backoff: %.1f seconds", delay)
            await self.sleep(delay)
            delay = min(delay * 2, self.max_retry_delay)


def kline_event(price, *, closed=False):
    """Synthetic Binance-shaped payload, explicitly for the offline demonstration."""
    return json.dumps({"e": "kline", "k": {
        "t": 0, "T": 3599999, "c": str(price), "x": closed,
    }})


class SimulatedSockets:
    """Inject deterministic socket messages/disconnections into the real Binance parser."""

    def __init__(self, sessions):
        self.sessions = iter(sessions)
        self.urls = []
        self.closed = 0

    @asynccontextmanager
    async def connect(self, url):
        steps = iter(next(self.sessions))
        self.urls.append(url)
        logger.info("SIMULATED connection #%s: %s", len(self.urls), url)

        class Socket:
            def __aiter__(self):
                return self

            async def __anext__(self):
                try:
                    step = next(steps)
                except StopIteration:
                    raise StopAsyncIteration from None
                if isinstance(step, Exception):
                    raise step
                if isinstance(step, asyncio.Event):
                    await step.wait()
                    raise StopAsyncIteration
                return step

        try:
            yield Socket()
        finally:
            self.closed += 1


async def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true", help="Connect to real Binance Spot")
    parser.add_argument("--events", type=int, default=4, help="Number of events to print (live only)")
    args = parser.parse_args()
    if args.events < 1:
        parser.error("--events must be positive")
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    sockets = SimulatedSockets([
        [kline_event(100), kline_event(101, closed=True), OSError("Simulated disconnect")],
        [kline_event(102), kline_event(103, closed=True)],
    ])
    print("LIVE public Binance data" if args.live else "SIMULATED data: no real network connection")
    async with httpx.AsyncClient() as http:
        client = BinanceClient(Settings(_env_file=None, binance_market="spot"), http)
        monitor = ReconnectingKlineStream(client, connect=None if args.live else sockets.connect)
        async with aclosing(monitor.events()) as events:
            count = 0
            async for candle, closed in events:
                print(f"BTCUSDT 1H close={candle.close} candle_closed={closed}")
                count += 1
                if count >= (args.events if args.live else 4):
                    break


if __name__ == "__main__":
    asyncio.run(main())
