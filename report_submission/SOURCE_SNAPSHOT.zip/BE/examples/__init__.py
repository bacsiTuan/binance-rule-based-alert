"""Standalone demonstrations; not started by FastAPI or the Telegram scheduler."""
