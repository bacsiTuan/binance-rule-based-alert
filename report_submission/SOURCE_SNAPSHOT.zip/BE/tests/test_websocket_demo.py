import asyncio
from contextlib import aclosing
from types import SimpleNamespace
from unittest.mock import AsyncMock

import httpx
import pytest
from examples.websocket_demo import (
    SESSION_SECONDS,
    ReconnectingKlineStream,
    SimulatedSockets,
    kline_event,
)

from app.config import Settings
from app.errors import BinanceError
from app.service.binance_client import BinanceClient


@pytest.fixture
async def client():
    def no_http(request):
        raise AssertionError("Streaming must not poll the REST API")

    async with httpx.AsyncClient(transport=httpx.MockTransport(no_http)) as http:
        yield BinanceClient(Settings(_env_file=None, binance_market="spot"), http)


async def take(monitor, count):
    result = []
    async with aclosing(monitor.events()) as events:
        for _ in range(count):
            result.append(await anext(events))
    return result


async def test_multiple_updates_reuse_connection_and_reconnect_after_disconnect(client):
    sockets = SimulatedSockets([
        [kline_event(100), kline_event(101, closed=True), OSError("Disconnected")],
        [kline_event(102)],
    ])
    sleep = AsyncMock()
    monitor = ReconnectingKlineStream(client, connect=sockets.connect, sleep=sleep)
    events = await take(monitor, 3)
    assert [(c.close, closed) for c, closed in events] == [
        ("100", False), ("101", True), ("102", False),
    ]
    assert sockets.urls == ["wss://stream.binance.com:9443/ws/btcusdt@kline_1h"] * 2
    assert sockets.closed == 2
    sleep.assert_awaited_once_with(1)


async def test_failed_connections_back_off_with_a_cap(client):
    sockets = SimulatedSockets([[OSError("Disconnected")]] * 4 + [[kline_event(100)]])
    sleep = AsyncMock()
    await take(ReconnectingKlineStream(
        client, connect=sockets.connect, sleep=sleep, max_retry_delay=4,
    ), 1)
    assert [call.args[0] for call in sleep.await_args_list] == [1, 2, 4, 4]


async def test_successful_event_resets_backoff(client):
    sockets = SimulatedSockets([
        [OSError("Disconnected")], [OSError("Disconnected")],
        [kline_event(100), OSError("Disconnected")], [kline_event(101)],
    ])
    sleep = AsyncMock()
    await take(ReconnectingKlineStream(client, connect=sockets.connect, sleep=sleep), 2)
    assert [call.args[0] for call in sleep.await_args_list] == [1, 2, 1]


async def test_session_renewal_simulates_hours_without_waiting(client):
    now = [0]
    sockets = SimulatedSockets([[kline_event(100), kline_event(999)], [kline_event(101)]])
    sleep = AsyncMock()
    monitor = ReconnectingKlineStream(client, connect=sockets.connect, sleep=sleep,
                                     clock=lambda: now[0])
    async with aclosing(monitor.events()) as events:
        assert (await anext(events))[0].close == "100"
        now[0] += SESSION_SECONDS + 1  # Advance virtual time by 23h50m, not wall-clock time.
        assert (await anext(events))[0].close == "101"
    assert sockets.closed == 2 and len(sockets.urls) == 2
    sleep.assert_not_awaited()


async def test_idle_connection_is_renewed_without_waiting_for_an_event(client):
    sockets = SimulatedSockets([[asyncio.Event()], [kline_event(101)]])
    monitor = ReconnectingKlineStream(client, connect=sockets.connect, session_seconds=0.02)
    events = await asyncio.wait_for(take(monitor, 1), timeout=2)
    assert events[0][0].close == "101" and sockets.closed == 2


async def test_cancellation_closes_socket_without_reconnecting(client):
    sockets = SimulatedSockets([[kline_event(100), asyncio.Event()]])
    sleep = AsyncMock()
    monitor = ReconnectingKlineStream(client, connect=sockets.connect, sleep=sleep)
    async with aclosing(monitor.events()) as events:
        await anext(events)
        task = asyncio.create_task(anext(events))
        await asyncio.sleep(0)
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task
    assert sockets.closed == 1 and len(sockets.urls) == 1
    sleep.assert_not_awaited()


async def test_nonretryable_error_is_not_hidden_by_reconnection():
    async def invalid_stream(*args, **kwargs):
        raise BinanceError("Invalid configuration", retryable=False)
        yield  # Make this a stream factory; no item is emitted.

    monitor = ReconnectingKlineStream(SimpleNamespace(stream_klines=invalid_stream))
    with pytest.raises(BinanceError, match="Invalid configuration"):
        await take(monitor, 1)


@pytest.mark.parametrize("seconds", [0, -1, 86400, float("nan"), float("inf")])
def test_session_lifetime_must_remain_below_binance_limit(seconds):
    with pytest.raises(ValueError):
        ReconnectingKlineStream(None, session_seconds=seconds)
